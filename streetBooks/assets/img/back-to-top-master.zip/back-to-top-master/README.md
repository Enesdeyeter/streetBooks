Back to Top
=========

A "Back to top" link to smoothly scroll back to the top of the page.

[Article on CodyHouse](http://codyhouse.co/gem/back-to-top/)

[Demo](http://codyhouse.co/demo/back-to-top/)
 
[Terms](http://codyhouse.co/terms/)
